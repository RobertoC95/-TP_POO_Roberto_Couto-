package Characters;

import Items.ItemHeroi;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Vendedor {

    private ArrayList<ItemHeroi> inventarioVendedor = new ArrayList<ItemHeroi>();

    public Vendedor(ArrayList<ItemHeroi> inventarioVendedor) {
        this.inventarioVendedor = inventarioVendedor;
    }

    /**
     * Metodo para criar a lista de 10 items aliatorios e vender ao jogador
     */
    public void itemsAleatorios(Heroi heroi) throws InterruptedException {

        Random rd = new Random();
        int itensApresentados = 0;
        int nRandom = 0;
        ArrayList<ItemHeroi> listaTemporaria = new ArrayList<ItemHeroi>();

        System.out.println("Wandering Trader: Huh huh");
        System.out.println("Narrator: This are the items you will have available this time: ");
        System.out.println();


        //criar e apresentar loja temporaria
        if (inventarioVendedor.size() > 10) {

            while (itensApresentados < 10) {

                nRandom = rd.nextInt(inventarioVendedor.size());
                boolean repetido = false;

                for (ItemHeroi itemHeroi : listaTemporaria) {
                    if (inventarioVendedor.get(nRandom) == itemHeroi) {
                        repetido = true;
                        break;
                    }

                }
                if (!repetido) {
                    listaTemporaria.add(inventarioVendedor.get(nRandom));
                    itensApresentados++;
                }
            }
            System.out.println("*** you have " + heroi.getOuro() + " gold ***   ");
            for (ItemHeroi itemHeroi : listaTemporaria) {
                itemHeroi.exibirDetalhes();
            }
        }

        if (inventarioVendedor.size() <= 10) {

            System.out.println("Narrator: It looks like the Wandering trader is running low on inventory...");
            System.out.println("Narrator: This is all he as left:");

            System.out.println("*** you have " + heroi.getOuro() + " gold ***   ");
            for (ItemHeroi itemHeroi : listaTemporaria) {
                itemHeroi.exibirDetalhes();
            }
        }
        System.out.println();

        if (inventarioVendedor.isEmpty()){
            System.out.println("*** empty bag ***");
        }

        Scanner input = new Scanner(System.in);
        boolean sairLoja;

        // vender elemento da lista temporaria ao jogador
        do {

            boolean entrou = false;
            boolean itemAdquirido = false;
            ItemHeroi cloneItem = null;
            sairLoja = false;
            boolean disponivel = false;
            String itemDesejado = "";
            System.out.println("Narrator: What item are you looking to acquire? or type 'leave' to continue!");
            System.out.println();
            System.out.println(heroi.getClass().getSimpleName());
            System.out.println("*** insert item name ***");

            itemDesejado = input.nextLine();

            if (itemDesejado.equalsIgnoreCase("leave")) {

                System.out.println();
                System.out.println(heroi.getNome() + ": You've got nothing that I want!");
                System.out.println();
                Thread.sleep(1000);
                System.out.println("Narrator: And there he goes... Those poor Llamas.");
                System.out.println();
                Thread.sleep(2000);
                sairLoja = true;
            }

            if (!sairLoja) {

                for (ItemHeroi itemHeroi : listaTemporaria) {

                    if (itemHeroi.getNome().equalsIgnoreCase(itemDesejado) && itemHeroi.getPreco() > heroi.getOuro()) {

                        System.out.println("Wandering Trader: Huh huh!");
                        System.out.println();
                        Thread.sleep(1000);
                        System.out.println("Narrator: I don't think you have the facilities for that big Man!");
                        System.out.println();
                        Thread.sleep(1000);
                        System.out.println("Narrator: Maybe try something cheaper.");
                        System.out.println();
                        System.out.println();
                        itemAdquirido = true;

                    }

                    disponivel = itemHeroi.getNome().equalsIgnoreCase(itemDesejado) && itemHeroi.getPreco() <= heroi.getOuro() && !itemAdquirido;

                    if (disponivel) {

                        if (itemHeroi.getHeroisPermitidos().contains(heroi.getClass().getSimpleName()) || itemHeroi.getHeroisPermitidos().contains("Todos")) {


                            cloneItem = itemHeroi;
                            heroi.itemComprado(cloneItem);
                            heroi.setOuro(heroi.getOuro() - cloneItem.getPreco());
                            System.out.println();
                            System.out.println("**" + itemHeroi.getNome() + " added to your inventory**");
                            System.out.println("Updated balance: " + heroi.getOuro() + " ouro");
                            System.out.println();
                            heroi.exibirDetalhes();
                            System.out.println();
                            System.out.println();


                            itemAdquirido = true;

                        }

                        //verificar se o heroi e o item sao compativeis

                        if (itemHeroi.getHeroisPermitidos().contains("Arqueiro") && !heroi.getClass().getSimpleName().contains("Arqueiro")) {

                            System.out.println("Narrator: It's not the time to be Legolas!");
                            System.out.println();
                            entrou = true;

                        } else if (itemHeroi.getHeroisPermitidos().contains("Cavaleiro") && !heroi.getClass().getSimpleName().contains("Cavaleiro")) {

                            System.out.println("Narrator: It's not the time to play with swords!");
                            System.out.println();
                            entrou = true;

                        } else if (itemHeroi.getHeroisPermitidos().contains("Feiticeiro") && !heroi.getClass().getSimpleName().contains("Feiticeiro")) {

                            System.out.println("Narrator: We both know the letter from Hogwarts never came!");
                            System.out.println();
                            entrou = true;

                        }
                    }

                }

                inventarioVendedor.remove(cloneItem);


                if (!entrou && !itemAdquirido) {
                    System.out.println("Wandering Trader: Huh huh");
                    Thread.sleep(500);
                    System.out.println("Narrator: It looks like that item is not available.");
                    System.out.println();
                }

            }


        } while (!sairLoja);
    }
}







































