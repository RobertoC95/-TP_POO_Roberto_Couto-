package Characters;

public class NPC extends Entidade{

    private int ouro;

    public NPC(String nome, int currentHP, int maxHP, int forca, int ouro) {
        super(nome, currentHP, maxHP, forca);
        this.ouro = ouro;
    }

    public int getOuro() {
        return ouro;
    }


    @Override
    public void exibirDetalhes() {
        System.out.println();
        System.out.println("** "+ getNome() + " stats **");
        System.out.println();
        super.exibirDetalhes();
        System.out.println("Gold: " + getOuro());
    }
}
