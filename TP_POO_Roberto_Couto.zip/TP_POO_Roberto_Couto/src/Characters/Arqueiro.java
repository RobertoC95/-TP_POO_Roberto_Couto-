package Characters;

import Items.ArmaPrincipal;
import Items.ItemHeroi;

import java.util.ArrayList;
import java.util.Scanner;

public class Arqueiro extends Heroi {


    public Arqueiro(String nome, int currentHP, int maxHP, int forca, int nivel, int ouro, ArmaPrincipal armaPrincipal) {
        super(nome, currentHP, maxHP, forca, nivel, ouro, armaPrincipal);
    }

    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
    }

    /**
     * Metodo para a luta especifica do arqueiro
     *
     * @param npc adversario no proximo combate
     * @return o metodo devolve 'true' se o heroi sobrevieu e 'false' se o heroi morreu
     */
    public boolean atacar(NPC npc) throws InterruptedException {

        Scanner input = new Scanner(System.in);
        int opcao;
        boolean especialUsado = false;
        boolean sobreviveu = true;

        npc.setDano((int) (npc.getForca() * 1.1)); // condição especial arqueiro
        npc.exibirDetalhes();
        System.out.println();

        exibirDetalhes();


        do {

            if (currentHP > 0 && npc.getCurrentHP() > 0) {

                System.out.println();
                System.out.println();
                System.out.println("Narrator: It's time to make your move!");
                Thread.sleep(2000);
                System.out.println();
                System.out.println("Narrator: What will it be?");
                Thread.sleep(2000);
                System.out.println();


                do {

                    System.out.println("*_*_* Fight options *_*_*");
                    System.out.println();
                    System.out.println("1- Normal Attack");
                    System.out.println("2- Special Attack- main weapon damage: " +  ((getForca()) + (armaPrincipal.getAtaqueEspecial())));
                    System.out.println("3- Use Consumable");
                    System.out.println("Option: ");
                    System.out.println();
                    opcao = input.nextInt();

                    switch (opcao) {

                        case 1:

                            npc.setCurrentHP(npc.getCurrentHP() - getForca());
                            npc.exibirDetalhes();
                            break;

                        case 2:


                            if (especialUsado) {

                                System.out.println("Narrator: You already used it in this fight!");
                                Thread.sleep(1000);
                                System.out.println();
                            }

                            if (!especialUsado) {

                                npc.setCurrentHP(npc.getCurrentHP() - getForca() - armaPrincipal.getAtaque());
                                npc.exibirDetalhes();


                            }
                            break;

                        case 3:
                            if (!inventario.isEmpty()) {
                                usarConsumivelCombate(npc);
                                opcao = 1;
                            }
                            if (inventario.isEmpty() && opcao != 1) {
                                System.out.println();
                                System.out.println("Narrator: There is something going on!");
                                Thread.sleep(1000);
                                System.out.println("Narrator: The inventory key is not working properly!");
                                Thread.sleep(1000);
                                System.out.println("Narrator: I think the inventory is empty");
                                Thread.sleep(1000);
                                System.out.println();
                            }
                            break;

                        default:
                            break;
                    }
                } while (opcao < 1 || opcao == 2 && especialUsado || opcao > 2);
                especialUsado = true;
            }

            if (npc.getCurrentHP() > 0) {

                System.out.println();
                System.out.println("Narrator: Watch out! Here he comes !");
                Thread.sleep(2000);
                System.out.println();
                currentHP -= npc.getForca();
                exibirDetalhes();
                System.out.println();
            }

        } while (getCurrentHP() > 0 && npc.getCurrentHP() > 0);

        if (npc.getCurrentHP() <= 0) {

            System.out.println();
            System.out.println("Narrator: You defeated your opponent!");
            Thread.sleep(2000);
            System.out.println();
            System.out.println();
            System.out.println("*** Level Up ***");
            Thread.sleep(2000);
            setOuro(getOuro() + npc.getOuro());
            subirNIvel();
            Thread.sleep(2000);
            exibirDetalhes();
            Thread.sleep(2000);
            System.out.println();
            System.out.println();
        }
        if (getCurrentHP() < 0) {
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println("************************ you dead ************************");
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            Thread.sleep(5000);
            return false;
        }

        return true;
    }

}
