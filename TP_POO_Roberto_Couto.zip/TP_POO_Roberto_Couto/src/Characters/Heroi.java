package Characters;

import Items.*;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class Heroi extends Entidade {

    protected int nivel;
    protected int ouro;
    protected ArmaPrincipal armaPrincipal;
    protected ArrayList<ItemHeroi> inventario = new ArrayList<ItemHeroi>();

    public Heroi(String nome, int currentHP, int maxHP, int forca, int nivel, int ouro, ArmaPrincipal armaPrincipal) {
        super(nome, currentHP, maxHP, forca);
        this.nivel = nivel;
        this.ouro = ouro;
        this.armaPrincipal = armaPrincipal;
    }

    public int getNivel() {
        return nivel;
    }

    public int getOuro() {
        return ouro;
    }

    public ArmaPrincipal getArmaPrincipal() {
        return armaPrincipal;
    }

    public ArrayList<ItemHeroi> getInventario() {
        return inventario;
    }


    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public void setOuro(int ouro) {
        this.ouro = ouro;
    }


    public void itemComprado(ItemHeroi itemHeroi) {
        inventario.add(itemHeroi);
    }

    public void itemUsado(ItemHeroi itemHeroi) {
        inventario.remove(itemHeroi);
    }

    @Override
    public void exibirDetalhes() {
        System.out.println();
        System.out.println("** player stats **");
        System.out.println();
        System.out.println("Level: " + this.nivel);
        super.exibirDetalhes();
        System.out.println("Main Weapon: " + armaPrincipal.getNome());
        System.out.println("Gold: " + this.ouro);
        System.out.println();
        if (!inventario.isEmpty()) {
            System.out.println(" **Inventory** ");
            System.out.println();
            for (ItemHeroi itemHeroi : inventario) {
                System.out.println(itemHeroi.getNome());
            }
        }

    }


    /**
     * metodo para fazer upgrade depois de vencer uma batalha
     */
    public void subirNIvel() {
        setNivel(getNivel() + 1);
        setCurrentHP((getCurrentHP() + (10)));
        setMaxHP((getMaxHP() + (10)));
        setDano((getForca() + (1)));
    }

    /**
     * Metodo para usar os diferentes tipos de consumiveis
     *
     * @throws InterruptedException
     */
    public void usarConsumivel() throws InterruptedException {

        Scanner input = new Scanner(System.in);
        boolean sairLoja;
        int nItems = 0;
        boolean consumivelUsado = false;
        String usar = "";
        ItemHeroi cloneItem = null;

        System.out.println("Narrator: You can have a little break now");
        Thread.sleep(4000);
        do {
            sairLoja = false;

            System.out.println("Narrator: Time to pick yourself back up!");
            System.out.println();
            System.out.println("**_Consumable available_**");

            for (ItemHeroi itemHeroi : getInventario()) {

                System.out.println(itemHeroi.getNome());
                nItems++;
            }
            System.out.println();

            if (nItems == 0) {

                System.out.println("*** empty ***");
                Thread.sleep(500);
                System.out.println("Narrator: Try and use the money.");
                Thread.sleep(500);
                System.out.println("Narrator: you can't make a withdraw to your bank account you know...");
                System.out.println();
                System.out.println();
                consumivelUsado = true;
                sairLoja = true;
            }


            if (nItems > 0) {

                System.out.println("Narrator: What consumable would you like to use? or type 'leave' to continue!");
                System.out.println();
                usar = input.nextLine();
                if (usar.equalsIgnoreCase("leave")) {
                    sairLoja = true;
                }

                // verificar se pode ser usado

                for (ItemHeroi itemHeroi : getInventario()) {

                    if (!consumivelUsado) {

                        if (itemHeroi.getNome().equalsIgnoreCase(usar)) {

                            if (itemHeroi instanceof Upgrade) {

                               /* armaPrincipal.setAtaque((armaPrincipal.getAtaque() + ((Upgrade) itemHeroi).getAumentoForca()));
                                ((ArmaPrincipal) itemHeroi).setAtaqueEspecial(((ArmaPrincipal) itemHeroi).getAtaqueEspecial() * 3);*/

                                armaPrincipal.setAtaque(armaPrincipal.getAtaque() + ((Upgrade)itemHeroi).getAumentoForca());
                                setDano(getForca() +((Upgrade)itemHeroi).getAumentoForca());
                                cloneItem = itemHeroi;
                                consumivelUsado = true;
                                sairLoja = true;
                                armaPrincipal.exibirDetalhes();
                                this.exibirDetalhes();
                                System.out.println();
                            }

                            if (itemHeroi instanceof Pocao) {

                                int desperdicio = (getCurrentHP() + ((Pocao) itemHeroi).getVidaCurar()) - (getMaxHP());

                                if (desperdicio > 0) {
                                    System.out.println("*** " + desperdicio + " Hp wasted ***");
                                    Thread.sleep(500);
                                    System.out.println();
                                    System.out.println("*** Are you sure? ***");
                                    System.out.println();
                                    System.out.println("1 - No");
                                    System.out.println("2 - Yes");
                                    int sure = input.nextInt();


                                    switch (sure) {
                                        case 1:
                                            sairLoja = true;
                                            break;
                                        case 2:

                                            setCurrentHP(getCurrentHP() + ((Pocao) itemHeroi).getVidaCurar());
                                            setDano(getForca() + ((Pocao) itemHeroi).getAumentoForca());

                                            System.out.println();
                                            if (getCurrentHP() > getMaxHP()) {
                                                setCurrentHP(getMaxHP());
                                            }
                                            cloneItem = itemHeroi;
                                            consumivelUsado = true;
                                            sairLoja = true;
                                            System.out.println();
                                            System.out.println();

                                    }

                                } else {
                                    setCurrentHP(getCurrentHP() + ((Pocao) itemHeroi).getVidaCurar());
                                    setDano(getForca() + ((Pocao) itemHeroi).getAumentoForca());

                                    System.out.println();

                                    if (getCurrentHP() > getMaxHP()) {
                                        setCurrentHP(getMaxHP());
                                    }
                                    cloneItem = itemHeroi;
                                    consumivelUsado = true;
                                    sairLoja = true;
                                    System.out.println();
                                    System.out.println();
                                }
                            }
                        }
                    }
                }
            }
        } while (!sairLoja);
        itemUsado(cloneItem);
        System.out.println();
        System.out.println();
        exibirDetalhes();
    }

    /**
     * Metodo para usar consumiveis de combate
     *
     * @throws InterruptedException
     */
    public void usarConsumivelCombate(NPC npc) throws InterruptedException {

        Scanner input = new Scanner(System.in);
        boolean sairLoja;
        int nItems = 0;
        boolean consumivelUsado = false;
        String usar = "";
        ItemHeroi cloneItem = null;

        do {
            sairLoja = false;

            System.out.println("**_Consumable available_**");
            System.out.println();

            for (ItemHeroi itemHeroi : getInventario()) {

                System.out.println(itemHeroi.getNome());
                nItems++;
            }

            if (nItems == 0) {

                System.out.println("*** empty ***");
                Thread.sleep(500);
                System.out.println("Narrator: Try and use the money.");
                Thread.sleep(500);
                System.out.println("Narrator: you can't make a withdraw to your bank account you know...");
                consumivelUsado = true;
                sairLoja = true;
            }


            if (nItems > 0) {

                System.out.println("Narrator: What consumable would you like to use? or type 'leave' to continue!");
                System.out.println();
                usar = input.nextLine();
                if (usar.equalsIgnoreCase("leave")) {
                    sairLoja = true;
                }

                // verificar se pode ser usado

                for (ItemHeroi itemHeroi : getInventario()) {

                    if (!consumivelUsado && itemHeroi.getNome().equalsIgnoreCase(usar)) {

                        if (itemHeroi instanceof Pocao || itemHeroi instanceof Upgrade) {
                            System.out.println();
                            System.out.println("*** Not available in battle ***");
                            consumivelUsado = true;
                            sairLoja = true;
                        }

                        if (itemHeroi instanceof ConsumivelCombate) {

                            int desperdicio = (getCurrentHP() + ((ConsumivelCombate) itemHeroi).getVidaCurar()) - (getMaxHP() + ((ConsumivelCombate) itemHeroi).getAumentoHP());
                            if (desperdicio > 0) {


                                System.out.println("*** " + desperdicio + " Hp wasted ***");
                                Thread.sleep(500);
                                System.out.println();
                                System.out.println("*** Are you sure? ***");
                                System.out.println();
                                System.out.println("1 - No");
                                System.out.println("2 - Yes");
                                int sure = input.nextInt();


                                switch (sure) {
                                    case 1:
                                        sairLoja = true;
                                        break;
                                    case 2:

                                        setCurrentHP(getCurrentHP() + ((ConsumivelCombate) itemHeroi).getVidaCurar());
                                        setMaxHP(getMaxHP() + ((ConsumivelCombate) itemHeroi).getAumentoHP());
                                        setDano(getForca() + ((ConsumivelCombate) itemHeroi).getAtaqueInstantaneo());
                                        npc.setCurrentHP(npc.getCurrentHP() - ((ConsumivelCombate) itemHeroi).getAtaqueInstantaneo());

                                        System.out.println();
                                        npc.exibirDetalhes();
                                        if (getCurrentHP() > getMaxHP()) {
                                            setCurrentHP(getMaxHP());
                                        }
                                        cloneItem = itemHeroi;
                                        consumivelUsado = true;
                                        sairLoja = true;
                                        System.out.println();
                                        System.out.println();
                                        this.exibirDetalhes();

                                }
                            } else {
                                setCurrentHP(getCurrentHP() + ((ConsumivelCombate) itemHeroi).getVidaCurar());
                                setMaxHP(getMaxHP() + ((ConsumivelCombate) itemHeroi).getAumentoHP());
                                setDano(getForca() + ((ConsumivelCombate) itemHeroi).getAtaqueInstantaneo());
                                npc.setCurrentHP(npc.getCurrentHP() - ((ConsumivelCombate) itemHeroi).getAtaqueInstantaneo());
                                System.out.println();
                                npc.exibirDetalhes();

                                if (getCurrentHP() > getMaxHP()) {
                                    setCurrentHP(getMaxHP());
                                }
                                cloneItem = itemHeroi;
                                consumivelUsado = true;
                                sairLoja = true;
                                System.out.println();
                                System.out.println();
                                exibirDetalhes();
                                System.out.println();
                                System.out.println();
                            }
                        }
                    }
                }
            }
        } while (!sairLoja);
        itemUsado(cloneItem);
        System.out.println();
        System.out.println();
        exibirDetalhes();
    }

    public abstract boolean atacar(NPC npc) throws InterruptedException;


}
