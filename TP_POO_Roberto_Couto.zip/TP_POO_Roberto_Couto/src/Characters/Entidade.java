package Characters;

public abstract class Entidade {

    protected String nome;
    protected int currentHP;
    protected int maxHP;
    protected int forca;

    public Entidade(String nome, int currentHP, int maxHP, int forca) {
        this.nome = nome;
        this.currentHP = currentHP;
        this.maxHP = maxHP;
        this.forca = forca;
    }

    public String getNome() {
        return nome;
    }

    public int getCurrentHP() {
        return currentHP;
    }

    public int getMaxHP() {
        return maxHP;
    }

    public int getForca() {
        return forca;
    }


    public void setCurrentHP(int currentHP) {
        this.currentHP = currentHP;
    }

    public void setMaxHP(int maxHP) {
        this.maxHP = maxHP;
    }

    public void setDano(int dano) {
        this.forca = dano;
    }


    public void exibirDetalhes() {
        System.out.println("Name: " + this.nome);
        System.out.println("HP: " + this.currentHP + "/" + this.maxHP);
        System.out.println("Damage: " + this.forca);
    }


}
