package Jogo;

import Characters.*;
import Items.*;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Jogo {


    /**
     * Metodo de crição de persongem
     *
     * @return devolve Heroi
     * @throws InterruptedException
     */
    public Heroi criarPersonagem() throws InterruptedException {

        Scanner input = new Scanner(System.in);

        System.out.println("Narrator: Welcome...");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: TO MODDED MINECRAFT!");
        Thread.sleep(1500);
        System.out.println();
        System.out.println("Narrator: kind of");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: but not really");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: To be fair this isn't really anything ");
        Thread.sleep(2500);
        System.out.println();
        System.out.println("Narrator: This guy has the creativity of a rock...");
        Thread.sleep(2500);
        System.out.println();
        System.out.println("Narrator: Anyway, lets get started!");
        Thread.sleep(1500);
        System.out.println();

        int heroiEscolhido = 0;
        String nomeJogador = "";

        do {
            System.out.println("Narrator: The time as come for you to decide what you want to be when you grow up:");
            Thread.sleep(3000);
            System.out.println();
            System.out.println("_*_ Options _*_");
            System.out.println("1- Knight");
            System.out.println("2- Wizard");
            System.out.println("3- Archer");
            System.out.println();
            System.out.println("Narrator: What is it going to be?");
            heroiEscolhido = input.nextInt();

            switch (heroiEscolhido) {

                case 1:
                    System.out.println("Narrator: So you want to be a Knight!");
                    Thread.sleep(1000);
                    System.out.println("Narrator: Maybe one day, you'll become, Arthur King of the Britons!");
                    Thread.sleep(1500);
                    break;

                case 2:
                    System.out.println("Narrator: So you want to be an Wizard!");
                    Thread.sleep(1000);
                    System.out.println("Narrator: Maybe one day, you'll become as good as, Tim the Enchanter!");
                    Thread.sleep(1500);
                    break;

                case 3:
                    System.out.println("Narrator: So you want to be an Archer!");
                    Thread.sleep(1000);
                    System.out.println("Narrator: Maybe one day, you'll become as good as, Steve, from Minecraft!");
                    Thread.sleep(1500);
                    break;

                default:
                    break;
            }
        } while (heroiEscolhido < 1 || heroiEscolhido > 3);

        System.out.println();
        System.out.println("*** Insert username ***");
        input.nextLine();
        nomeJogador = input.next();
        System.out.println();
        System.out.println();

        System.out.println("Narrator: " + nomeJogador + ", huh? ");
        Thread.sleep(2000);
        System.out.println("Narrator: You didn't get to choose your name when you were born, your not going to do it now!");
        Thread.sleep(2500);
        System.out.println("Narrator: Go and change it, I'll wait.");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: You're still here?");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: OK, fine, i guess you'll be " + nomeJogador + ".");
        Thread.sleep(1000);

        System.out.println();
        System.out.println("Narrator: Now that  we got to know each other a bit.");
        Thread.sleep(1000);
        System.out.println("Narrator: Let's see how brave you are!");
        Thread.sleep(1000);
        System.out.println();

        int dificuldade = 0;
        int pontosDistribuir = 0;
        int pontosVida = 0;
        int pontosForca = 0;
        int ouro = 0;

        do {
            System.out.println("_*_ Select Dificulty _*_");
            System.out.println("1- Easy");
            System.out.println("2- Hard");

            dificuldade = input.nextInt();

            switch (dificuldade) {

                case 1:
                    do {
                        pontosDistribuir = 300;
                        System.out.println("Narrator: You have " + pontosDistribuir + " points to increase starting Hp, and Strength.");
                        Thread.sleep(1500);
                        System.out.println();
                        System.out.println("Narrator: each Strength point costs 5 creation points");
                        Thread.sleep(2000);
                        System.out.println("Narrator: each Health point costs 1 creation points");
                        System.out.println();
                        Thread.sleep(2000);
                        System.out.println("* Insert Strength Points *");
                        pontosForca = input.nextInt();
                        pontosForca *= 5;
                        pontosDistribuir -= pontosForca;
                        System.out.println(pontosForca + " used, " + pontosDistribuir + " points remaining");
                        System.out.println();
                        System.out.println("* Insert Health Points *");
                        pontosVida = input.nextInt();
                        pontosDistribuir -= pontosVida;

                        if (pontosDistribuir != 0) {

                            System.out.println("*** invalid combination of points ***");
                            Thread.sleep(1500);
                            System.out.println("*** try again ***");
                        } else {

                        }

                    } while (pontosDistribuir != 0);
                    ouro = 20;

                    break;

                case 2:
                    do {
                        pontosDistribuir = 220;
                        System.out.println("Narrator: You have " + pontosDistribuir + " points to increase starting Hp, and Strength.");
                        Thread.sleep(2000);
                        System.out.println("Narrator: each Strenght point costs 5 creation points");
                        System.out.println();
                        Thread.sleep(2000);
                        System.out.println("Narrator: each Strenght point costs 1 creation points");
                        System.out.println();
                        Thread.sleep(2000);
                        System.out.println("* Insert Strenght Points *");
                        pontosForca = input.nextInt();
                        pontosForca *= 5;
                        pontosDistribuir -= pontosForca;
                        System.out.println(pontosForca + " used, " + pontosDistribuir + " points remaining");
                        System.out.println();
                        System.out.println("* Insert Strenght Points *");
                        pontosVida = input.nextInt();
                        pontosDistribuir -= pontosVida;

                        if (pontosDistribuir != 0) {

                            System.out.println("*** invalid combination of points ***");
                            Thread.sleep(1500);
                            System.out.println("*** try again ***");
                            System.out.println();
                            System.out.println();
                        }

                    } while (pontosDistribuir != 0);
                    ouro = 15;

                    break;
            }

        } while (dificuldade < 1 || dificuldade > 2);


        ArrayList<String> heroisPermitidos = new ArrayList<String>();
        ArmaPrincipal espada = new ArmaPrincipal("Diamond Sword", 0, heroisPermitidos, 20, 60);
        ArmaPrincipal arco = new ArmaPrincipal("Bow and Arrow", 0, heroisPermitidos, 20, 60);
        ArmaPrincipal varinha = new ArmaPrincipal("Common Wand", 0, heroisPermitidos, 20, 60);
        Heroi jogador = null;

        switch (heroiEscolhido) {

            case 1:

                jogador = new Cavaleiro(nomeJogador, pontosVida, pontosVida, pontosForca, 0, ouro, espada);
                System.out.println();
                System.out.println("** Player Created **");
                jogador.exibirDetalhes();
                break;

            case 2:
                jogador = new Arqueiro(nomeJogador, pontosVida, pontosVida, pontosForca, 0, ouro, arco);
                System.out.println("** Player Created **");
                jogador.exibirDetalhes();
                break;

            case 3:
                jogador = new Feiticeiro(nomeJogador, pontosVida, pontosVida, pontosForca, 0, ouro, varinha);
                System.out.println("** Player Created **");
                jogador.exibirDetalhes();
                break;
        }
        return jogador;
    }

    /**
     * Metodo para jogar o jogo
     *
     * @param jogador recebe como parametro o heroi criado ou clone no caso de restart
     * @throws InterruptedException
     */
    public void modedMinecraft(Heroi jogador) throws InterruptedException {

        Scanner input = new Scanner(System.in);
        //Instanciar Item do Heroi

        ArrayList<String> heroisPermitidos = new ArrayList<String>();
        heroisPermitidos.add("Todos");
        ArrayList<String> cavaleiroPermitido = new ArrayList<String>();
        cavaleiroPermitido.add("Cavaleiro");
        ArrayList<String> arqueiroPermitido = new ArrayList<String>();
        arqueiroPermitido.add("Arqueiro");
        ArrayList<String> feiticeiroPermitido = new ArrayList<String>();
        feiticeiroPermitido.add("Feiticeiro");

        //Consumiveis Combate
        ConsumivelCombate goldenApple = new ConsumivelCombate("Golden Apple", 200, heroisPermitidos, 0, 150, 100);
        ConsumivelCombate godApple = new ConsumivelCombate("Notch Apple", 500, heroisPermitidos, 0, 500, 500);
        ConsumivelCombate regeneration = new ConsumivelCombate("Potion of Regeneration", 50, heroisPermitidos, 0, 50, 0);
        ConsumivelCombate HAG = new ConsumivelCombate("Holy Hand Grenade of Antioch", 500, heroisPermitidos, 1000, 0, 0);


        //Upgrades
        Upgrade sharpness = new Upgrade("Sharpness V", 50, cavaleiroPermitido, 50);
        Upgrade fireAspect = new Upgrade("Fire Aspect", 50, cavaleiroPermitido, 50);
        Upgrade power = new Upgrade("Power V", 50, arqueiroPermitido, 50);
        Upgrade punch = new Upgrade("Punch II", 50, arqueiroPermitido, 50);
        Upgrade flame = new Upgrade("Flame", 50, feiticeiroPermitido, 50);
        Upgrade smite = new Upgrade("Smite V", 50, feiticeiroPermitido, 50);
        Upgrade bible = new Upgrade("Holy Bible", 50, heroisPermitidos, 50);

        //Poções
        Pocao healing = new Pocao("Potion of Healing", 10, heroisPermitidos, 22, 0);
        Pocao healingII = new Pocao("Potion of Healing II", 30, heroisPermitidos, 45, 0);
        Pocao healingIII = new Pocao("Potion of Healing III", 50, heroisPermitidos, 70, 0);
        Pocao strength = new Pocao("Potion of Strength", 10, heroisPermitidos, 0, 22);
        Pocao strengthII = new Pocao("Potion of StrengthII", 30, heroisPermitidos, 0, 45);
        Pocao strengthIII = new Pocao("Potion of StrengthIII", 50, heroisPermitidos, 0, 70);

        //Inimigos

        NPC npc01 = new NPC("Zombie", 25, 25, 5, 10);
        NPC npc02 = new NPC("Zombie", 25, 25, 5, 10);
        NPC npc03 = new NPC("Zombie", 25, 25, 5, 10);
        NPC npcB01 = new NPC("Piglin", 35, 35, 15, 30);
        NPC npcB02 = new NPC("Enderman", 35, 35, 15, 30);
        NPC npcB03 = new NPC("Blaze", 40, 40, 20, 30);
        NPC dragao = new NPC("Ender Dragon", 2000, 2000, 75, 1000);

        //Vendedor
        ArrayList<ItemHeroi> lojaTemporaria = new ArrayList<ItemHeroi>();
        Vendedor WanderingTrader = new Vendedor(lojaTemporaria);
        lojaTemporaria.add(goldenApple);
        lojaTemporaria.add(godApple);
        lojaTemporaria.add(regeneration);
        lojaTemporaria.add(HAG);
        lojaTemporaria.add(sharpness);
        lojaTemporaria.add(fireAspect);
        lojaTemporaria.add(power);
        lojaTemporaria.add(punch);
        lojaTemporaria.add(flame);
        lojaTemporaria.add(smite);
        lojaTemporaria.add(bible);
        lojaTemporaria.add(healing);
        lojaTemporaria.add(healingII);
        lojaTemporaria.add(healingIII);
        lojaTemporaria.add(strength);
        lojaTemporaria.add(strengthII);
        lojaTemporaria.add(strengthIII);


        System.out.println("Narrator: Welcome back Steve!");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: Sorry, " + jogador.getNome() + " force of habit.");
        Thread.sleep(1000);
        System.out.println();
        System.out.println(jogador.getNome() + ": Can I go now?");
        Thread.sleep(1000);
        System.out.println();
        System.out.println("Narrator: You see that guy dragging two llamas by a lead?");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: That's the Wandering Trader, he has everything you will need...");
        Thread.sleep(2000);
        System.out.println();
        System.out.println(jogador.getNome() + ": Wasn't this suppose to be fast?");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: Just check what he has in store and let's go!");
        Thread.sleep(2000);
        System.out.println();

        WanderingTrader.itemsAleatorios(jogador);

        System.out.println("Narrator: Look, the WanderingTrader left a water bucket behind...");
        Thread.sleep(2500);
        System.out.println();

        boolean temBalde = false;
        int balde = 0;


        do {
            System.out.println("*** Will you take it? ***");
            System.out.println();
            System.out.println("1- yes");
            System.out.println("2- no");
            balde = input.nextInt();
            System.out.println();
            switch (balde) {

                case 1:
                    temBalde = true;
                    System.out.println("Narrator: You got it?");
                    break;

                case 2:
                    System.out.println("Narrator: Was that a mistake?");
                    break;

                default:
                    System.out.println("*** insert valid option ***");
                    break;
            }
        } while (balde < 1 || balde > 2);


        System.out.println();
        System.out.println("Narrator: It's time to look for a nether portal");
        Thread.sleep(2500);

        System.out.println();
        System.out.println("Narrator: Which route are you going to take?");
        Thread.sleep(2500);
        System.out.println();
        int portalNether = 0;
        Random rd = new Random();
        int nRandom = rd.nextInt(100);
        int perolas = 0;
        do {
            System.out.println("*** Pick an option ***");
            System.out.println();
            System.out.println("1- Look for a ruinned portal");
            System.out.println("2- Look for someone else's portal");
            portalNether = input.nextInt();
            System.out.println();
            switch (portalNether) {

                case 1:

                    System.out.println("Narrator: There is a portal over there!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Behind those mountains!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("*** On the way ***");
                    Thread.sleep(2000);
                    System.out.println();
                    Thread.sleep(2000);
                    System.out.println();
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: There is a mob there, and there is no way around...");
                    Thread.sleep(2000);
                    jogador.atacar(npc01);
                    if (jogador.getCurrentHP() <= 0) {
                        return;
                    }
                    System.out.println();
                    System.out.println("Narrator: He's not alone.");
                    System.out.println();
                    jogador.atacar(npc02);
                    if (jogador.getCurrentHP() <= 0) {
                        return;
                    }
                    System.out.println("Narrator: This might be the last one!");
                    Thread.sleep(2000);
                    jogador.atacar(npc03);
                    if (jogador.getCurrentHP() <= 0) {
                        return;
                    }
                    jogador.usarConsumivel();
                    System.out.println();
                    System.out.println("Narrator: You destroyed them!");
                    Thread.sleep(2000);
                    System.out.println("Narrator: Now, let's se if you get lucky with portal chest!");
                    System.out.println();
                    Thread.sleep(2000);

                    if (nRandom >= 75) {
                        perolas = 5;
                        System.out.println("*** " + perolas + " perolas found ***");
                    }
                    if (nRandom >= 50 && nRandom < 75) {
                        perolas = 4;
                        System.out.println("*** " + perolas + " perolas found ***");
                    }
                    if (nRandom >= 20 && nRandom < 50) {
                        perolas = 3;
                        System.out.println("*** " + perolas + " perolas found ***");
                    }
                    if (nRandom >= 5 && nRandom < 20) {
                        perolas = 2;
                        System.out.println("*** " + perolas + " perolas found ***");
                    }
                    if (nRandom < 5) {
                        perolas = 1;
                        System.out.println("*** " + perolas + " perolas found ***");
                    }
                    System.out.println();
                    System.out.println();
                    System.out.println("Narrator: Look who is back!");
                    Thread.sleep(2000);
                    WanderingTrader.itemsAleatorios(jogador);
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Are you done?");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Because it's time to go to the nether!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println();
                    System.out.println("*** entering portal ***");
                    System.out.println();
                    System.out.println();
                    Thread.sleep(4000);
                    System.out.println("Narrator: Get ready !");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: There is a Bastion in the distance...");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: You can use it to get the remaining ender Pearls!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: And who knows!Maybe a bit of extra gold!");
                    Thread.sleep(2000);

                    System.out.println();
                    do {

                        npcB01.setCurrentHP(npcB01.getMaxHP());
                        jogador.atacar(npcB01);
                        if (jogador.getCurrentHP() <= 0) {
                            return;
                        }
                        int randomGold = rd.nextInt(0, 50);
                        System.out.println("*** " + ((randomGold) + (npcB01.getOuro())) + " gold added to your balance ***");
                        jogador.setOuro(jogador.getOuro() + randomGold);
                        System.out.println();
                        if (randomGold <= 25) {
                            perolas += 3;
                        }
                        if (randomGold > 25) {
                            perolas += 2;
                        }
                        System.out.println("*** Ender pearls : " + perolas + " ***");
                        System.out.println();
                        System.out.println();
                    } while (perolas < 12);

                    jogador.usarConsumivel();

                    break;

                case 2:
                    int opCaverna = 0;

                    System.out.println("Narrator: Let's explore that cave!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: It looks like somebody as already been there...");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("*** On the way ***");
                    Thread.sleep(2000);
                    System.out.println();
                    Thread.sleep(2000);
                    System.out.println();
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Get your Weapon ready, you're gonna need it!");
                    Thread.sleep(2000);
                    jogador.atacar(npc01);
                    if (jogador.getCurrentHP() <= 0) {
                        return;
                    }
                    System.out.println();
                    System.out.println("Narrator: He's not alone.");
                    Thread.sleep(2000);
                    System.out.println();

                    System.out.println("Narrator: You need to make a decision now!");
                    Thread.sleep(2000);
                    System.out.println("*** Pick an option");
                    System.out.println("1- figth it out");
                    System.out.println("2- mine straigth donw to escape");

                    do {
                        opCaverna = input.nextInt();

                        switch (opCaverna) {

                            case 1:
                                jogador.atacar(npc02);
                                if (jogador.getCurrentHP() <= 0) {
                                    return;
                                }
                                System.out.println("Narrator: This might be the last one!");
                                Thread.sleep(2000);
                                jogador.atacar(npc03);
                                if (jogador.getCurrentHP() <= 0) {
                                    return;
                                }
                                break;

                            case 2:
                                System.out.println();
                                System.out.println("Narrator: Be careful!!!");
                                Thread.sleep(1000);
                                Thread.sleep(2000);
                                System.out.println(jogador.getNome() + ": Aaaahhh!");
                                Thread.sleep(4000);
                                System.out.println("Narrator: You're headed straight for that lava pool");
                                Thread.sleep(3000);
                                if (temBalde) {
                                    System.out.println("Narrator: Quick try an MLG!");
                                    Thread.sleep(1500);
                                    int randomGold = rd.nextInt(0, 50);

                                    if (randomGold > 25) {
                                        System.out.println("Narrator: You did it!");
                                        Thread.sleep(1500);
                                    }
                                    if (randomGold <= 25) {
                                        System.out.println();
                                        System.out.println("**Tsssssss!**");
                                        jogador.setCurrentHP((jogador.getCurrentHP()) - 10);
                                        System.out.println("Narrator: Almost...");
                                        Thread.sleep(2000);
                                        System.out.println("Narrator: You lost " + 10 + " Hp");
                                        Thread.sleep(1500);
                                    }
                                    if (jogador.getCurrentHP() <= 0) {
                                        return;
                                    }
                                }
                                if (!temBalde) {

                                    System.out.println("Narrator: You should have brought the bucket...");
                                    Thread.sleep(500);
                                    int painCicle = 0;
                                    while (painCicle < 3) {
                                        int randomPain = rd.nextInt(0, 50);

                                        System.out.println("**Tsssssss!**");
                                        System.out.println("Narrator: You lost " + randomPain + " Hp");
                                        Thread.sleep(500);
                                        painCicle++;
                                    }
                                    if (jogador.getCurrentHP() <= 0) {
                                        return;
                                    }

                                }
                                System.out.println("Narrator: You survived the room!");
                                jogador.exibirDetalhes();
                                Thread.sleep(2000);
                                jogador.usarConsumivel();
                                System.out.println("*** tip ***");
                                System.out.println("*** never dig straight down ***");
                                break;

                            default:
                                System.out.println("*** invalid option ***");
                                break;
                        }
                    }
                    while (opCaverna < 1 || opCaverna > 2);


                    System.out.println();
                    System.out.println("Narrator: You made it!");
                    Thread.sleep(2000);
                    System.out.println("Narrator: Now, let's finally enter the Nether Dimension");
                    System.out.println();
                    Thread.sleep(2000);


                    System.out.println();
                    System.out.println("Narrator: But first");
                    System.out.println("Narrator: Look who is back!");
                    Thread.sleep(2000);
                    WanderingTrader.itemsAleatorios(jogador);
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Are you done?");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: Because it's time to go to the nether!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println();
                    System.out.println("*** entering portal ***");
                    System.out.println();
                    System.out.println();
                    Thread.sleep(4000);
                    System.out.println("Narrator: You spawned in a Warped forest biome!");
                    Thread.sleep(2000);
                    System.out.println();
                    System.out.println("Narrator: The best place to find the 12 ender pearl you need!");
                    Thread.sleep(2000);
                    System.out.println();

                    do {

                        npcB01.setCurrentHP(npcB01.getMaxHP());
                        jogador.atacar(npcB01);
                        if (jogador.getCurrentHP() <= 0) {
                            return;
                        }
                        int randomGold = rd.nextInt(0, 50);

                        System.out.println();
                        if (randomGold <= 25) {
                            perolas += 4;
                        }
                        if (randomGold > 25) {
                            perolas += 3;
                        }
                        System.out.println("*** Ender pearls : " + perolas + " ***");
                        System.out.println();
                        System.out.println();
                    } while (perolas < 12);

                    System.out.println();


                default:
                    System.out.println("*** insert valid option ***");
            }
        } while (portalNether < 1 || portalNether > 2);

        System.out.println("Narrator: Congratulations...");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: The only thing left for you to get");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: is to find a fortress!");
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: Kill some blazes, get 12 blaze rods and we're good to go!");
        Thread.sleep(2000);
        System.out.println();
        Thread.sleep(2000);
        System.out.println();
        System.out.println("Narrator: Keep you eyes open, there might be something along the way!");
        Thread.sleep(2000);
        System.out.println();
        int caminhosorte1 = rd.nextInt(100);
        int caminhosorte2 = rd.nextInt(100);
        int caminhosorte3 = rd.nextInt(100);
        int caminhosorte4 = rd.nextInt(100);

        if (caminhosorte1 < 33) {

            jogador.setOuro(jogador.getOuro() + caminhosorte4);
            System.out.println("*** jackpot ***");
            System.out.println("*** you have received " + caminhosorte4 + " gold");
        }
        if (caminhosorte2 < 33) {
            jogador.setOuro(jogador.getOuro() + caminhosorte4);
            System.out.println("*** jackpot ***");
            System.out.println("*** you have received " + caminhosorte4 + " gold");
        }
        if (caminhosorte3 < 33) {
            jogador.setOuro(jogador.getOuro() + caminhosorte4);
            System.out.println("*** jackpot ***");
            System.out.println("*** you have received " + caminhosorte4 + " gold");
        }
        if (caminhosorte1 + caminhosorte2 + caminhosorte3 < 100) {
            System.out.println("*** weapon uprade found ***");
            Thread.sleep(1000);
            System.out.println("*** Upgrade successful ***");
            Thread.sleep(1000);
            jogador.getArmaPrincipal().setAtaque((jogador.getArmaPrincipal().getAtaque()) * 3);
            Thread.sleep(1000);
            System.out.println();
            jogador.exibirDetalhes();
        }

        System.out.println("Narrator: Time for the fortress then.");
        System.out.println("Narrator: Kill some blazes, get 12 blaze rods and we're good to go!");
        Thread.sleep(2000);
        System.out.println();

        int blaze = 0;
        do {

            npcB01.setCurrentHP(npcB01.getMaxHP());
            jogador.atacar(npcB01);
            if (jogador.getCurrentHP() <= 0) {
                return;
            }
            int randomGold = rd.nextInt(0, 50);
            System.out.println("*** " + (npcB03.getOuro()) + " gold added to your balance ***");
            Thread.sleep(2000);
            System.out.println();
            Thread.sleep(2000);
            if (randomGold <= 25) {
                Thread.sleep(2000);
                blaze += 3;
            }
            if (randomGold > 25) {
                Thread.sleep(2000);
                blaze += 2;
            }
            System.out.println();
            Thread.sleep(2000);
            System.out.println("*** Ender pearls : " + perolas + " ***");
            Thread.sleep(2000);
            System.out.println();
            System.out.println();
        } while (blaze < 12);

        jogador.usarConsumivel();

        System.out.println("Narrator: It's finally time to get out of this hell hole!");
        Thread.sleep(2000);
        System.out.println("Narrator: It's to hot in here!");
        Thread.sleep(2000);
        System.out.println("*** traveling to overWorld ***");
        Thread.sleep(2000);
        System.out.println("Narrator: Oh look the one most expensive trader in the world is back!");
        WanderingTrader.itemsAleatorios(jogador);
        Thread.sleep(2000);


        // 50% prob de encontrar a wither

        int WitherChance = rd.nextInt(100);
        if (WitherChance >= 50){
            System.out.println("Narrator: Hurry the F up you can't miss this!");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: There are a group as 9 other players fighting the wither.");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: It's a good oportunity to get gold and levels.");
            Thread.sleep(2000);
            System.out.println("*** everything about this fight is randomized ***");

            int wither = 0;
            do {
                int randomWither = rd.nextInt(100);
                wither += (randomWither * 3);
                if ((1000 - wither) > 0) {
                    System.out.println(" *** wither " + (1000 - wither) + "/1000 hp ***");
                }
                Thread.sleep(1500);
                if (randomWither < 10) {
                    System.out.println("*** Damage Taken ***");
                    Thread.sleep(1500);
                    jogador.exibirDetalhes();
                    Thread.sleep(1500);
                }
                if (randomWither >= 10) {
                    System.out.println("*** Missed you ***");
                    Thread.sleep(1500);
                    jogador.exibirDetalhes();
                    Thread.sleep(1500);
                }
                if (jogador.getCurrentHP() <= 0) {
                    return;
                }
            } while (wither <= 1000);


            System.out.println();
            System.out.println("Narrator: The wither is dead congratulations!");
            Thread.sleep(1500);
            Thread.sleep(1500);
            System.out.println("*** Your reward ***");
            System.out.println();
            Thread.sleep(2000);
            System.out.println(" *** 500 gold ***");
            System.out.println(" *** 5 levels ***");
            jogador.setOuro((jogador.getOuro()) + 500);
            for (int i = 0; i < 5; i++) {
                jogador.subirNIvel();
                i++;
            }
            Thread.sleep(2000);
            jogador.exibirDetalhes();
        }




        System.out.println();
        System.out.println();
        System.out.println("Narrator: Go spend the rest of your coins with the mute guy, I'll brb");
        Thread.sleep(1500);
        WanderingTrader.itemsAleatorios(jogador);
        jogador.usarConsumivel();
        Thread.sleep(3000);
        System.out.println();
        System.out.println("*** after a long journey ***");
        System.out.println();
        Thread.sleep(4000);
        System.out.println("Narrator: This is where we go our separate ways!");
        System.out.println();
        Thread.sleep(2000);
        System.out.println("Narrator: It was a pleasure to assist you in this run!");
        System.out.println();
        Thread.sleep(2000);
        System.out.println("Narrator: Go get that dragon!");
        System.out.println();
        Thread.sleep(2000);
        Thread.sleep(2000);
        Thread.sleep(2000);
        System.out.println("*** strange voice ***");
        System.out.println();
        Thread.sleep(2000);
        System.out.println(jogador.getNome() + " : what was that?");
        System.out.println();
        Thread.sleep(2000);
        System.out.println("*** you turn around and see that massive head blocking out the sun ***");
        System.out.println();
        Thread.sleep(2000);
        System.out.println(" *** it looks like a beggar with a sign ***");
        System.out.println();
        Thread.sleep(2000);
        System.out.println("*** he approaches you ***");
        System.out.println();
        System.out.println(" Pedro Couto: Traveller please spare me some change!");
        System.out.println();
        Thread.sleep(2000);

        int doacao = 0;

        do {
            System.out.println("*** you have " + jogador.getOuro() + " gold ***");
            System.out.println("How much do you want to donate?");
            doacao = input.nextInt();

            if (doacao <= 0 || doacao > jogador.getOuro()) {
                System.out.println("*** invalid amount ***");
            } else {
                int pingo = 1 + (doacao / (jogador.getOuro()));

                jogador.setDano((jogador.getForca()) * pingo);
                jogador.setCurrentHP((jogador.getCurrentHP()) * pingo);
                jogador.setMaxHP((jogador.getMaxHP()) * pingo);
                jogador.getArmaPrincipal().setAtaqueEspecial((jogador.getArmaPrincipal().getAtaqueEspecial()) * pingo);
                Thread.sleep(2000);
                System.out.println(" Pedro Couto: Thank you sir!");
                Thread.sleep(2000);
                System.out.println();
                System.out.println(" Pedro Couto: please let me do something for you!");
                Thread.sleep(2000);
                System.out.println();
                System.out.println(" Pedro Couto: I'll make you as strong as you ever felt!");
                Thread.sleep(2000);
                Thread.sleep(2000);
                System.out.println();
                System.out.println(" *** after Pedro Couto's upgrade *** ");
                Thread.sleep(2000);
                jogador.setOuro(jogador.getOuro() - doacao);
                jogador.exibirDetalhes();
                System.out.println();
            }


        } while (doacao < 0 || doacao > jogador.getOuro());


        System.out.println(jogador.getNome() + " : Okay lets finally do it");
        Thread.sleep(2000);
        System.out.println(jogador.getNome() + " : That dragon is going down");
        Thread.sleep(2000);
        System.out.println(jogador.getNome() + " : It would be a great time to have Holy Hand Grenade of Antioch ");
        Thread.sleep(2000);
        jogador.atacar(dragao);

    }
}
