package Items;

import java.util.ArrayList;

public class ArmaPrincipal extends ItemHeroi{

    private int ataque;
    private int ataqueEspecial;

    public ArmaPrincipal(String nome, int preco, ArrayList<String> heroisPermitidos, int ataque, int ataqueEspecial) {
        super(nome, preco, heroisPermitidos);
        this.ataque = ataque;
        this.ataqueEspecial = ataqueEspecial;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getAtaqueEspecial() {
        return ataqueEspecial;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println(" | Damage: " + ataque);
        System.out.println();
    }

    public void setAtaqueEspecial(int ataqueEspecial) {
        this.ataqueEspecial = ataqueEspecial;
    }
}
