package Items;

import java.util.ArrayList;

public abstract class ItemHeroi {

    protected String nome;
    protected int preco;
    protected ArrayList<String> heroisPermitidos = new ArrayList<String>();

    public ItemHeroi(String nome, int preco, ArrayList<String> heroisPermitidos) {
        this.nome = nome;
        this.preco = preco;
        this.heroisPermitidos = heroisPermitidos;
    }

    public String getNome() {
        return nome;
    }

    public int getPreco() {
        return preco;
    }

    public ArrayList<String> getHeroisPermitidos() {
        return heroisPermitidos;
    }

    public void exibirDetalhes() {

        System.out.print("Name: " + this.nome + " | " + " Price: " + this.preco);
    }


}
