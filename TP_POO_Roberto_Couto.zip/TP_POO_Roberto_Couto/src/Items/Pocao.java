package Items;

import java.util.ArrayList;

public class Pocao extends ItemHeroi {

    private int vidaCurar;
    private int aumentoForca;

    public Pocao(String nome, int preco, ArrayList<String> heroisPermitidos, int vidaCurar, int aumentoForca) {
        super(nome, preco, heroisPermitidos);
        this.vidaCurar = vidaCurar;
        this.aumentoForca = aumentoForca;
    }

    public int getVidaCurar() {
        return vidaCurar;
    }

    public int getAumentoForca() {
        return aumentoForca;
    }

    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println(" | Health regeneration: " + this.vidaCurar + " | Damage upgrade: " + this.aumentoForca + " | " + heroisPermitidos);
    }
}
