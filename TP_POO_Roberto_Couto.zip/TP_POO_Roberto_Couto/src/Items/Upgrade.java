package Items;

import java.util.ArrayList;

public class Upgrade extends ItemHeroi {

    private int aumentoForca;

    public Upgrade(String nome, int preco, ArrayList<String> heroisPermitidos, int aumentoForca) {
        super(nome, preco, heroisPermitidos);
        this.aumentoForca = aumentoForca;
    }

    public int getAumentoForca() {
        return aumentoForca;
    }

    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println("| Damage MainWeapon: *3 | " + heroisPermitidos);
    }
}
