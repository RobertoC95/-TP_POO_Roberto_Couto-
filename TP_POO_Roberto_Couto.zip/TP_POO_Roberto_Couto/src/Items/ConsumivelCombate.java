package Items;

import java.util.ArrayList;

public class ConsumivelCombate extends Consumivel {

    private int ataqueInstantaneo;
    private int vidaCurar;
    private int aumentoHP;

    public ConsumivelCombate(String nome, int preco, ArrayList<String> heroisPermitidos, int ataqueInstantaneo, int vidaCurar, int aumentoHP) {
        super(nome, preco, heroisPermitidos);
        this.ataqueInstantaneo = ataqueInstantaneo;
        this.vidaCurar = vidaCurar;
        this.aumentoHP = aumentoHP;
    }

    public int getAtaqueInstantaneo() {
        return ataqueInstantaneo;
    }

    public int getVidaCurar() {
        return vidaCurar;
    }

    public int getAumentoHP() {
        return aumentoHP;
    }

    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println(" | Instant Damage: " + this.ataqueInstantaneo + " | Health regeneration: " + this.vidaCurar + " | Max HP upgrade: " + this.aumentoHP + " | " + heroisPermitidos);
    }
}
