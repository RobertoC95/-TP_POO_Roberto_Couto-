import Characters.Arqueiro;
import Characters.Cavaleiro;
import Characters.Feiticeiro;
import Characters.Heroi;
import Items.ArmaPrincipal;
import Jogo.Jogo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        Scanner input = new Scanner(System.in);
        int opcao = 0;


        //inicio do jogo

        do {
            Jogo novoJogo = new Jogo();

            Heroi jogador;
            jogador = novoJogo.criarPersonagem();

            System.out.println("Narrator: Now that you're ready to go, let me tell how this works...");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: This is an online server with multiple players.");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: So you can skip some work, or you can do it all from scratch.");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: The goal is to be the fastest player to end the game.");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("Narrator: So let's get started!");
            Thread.sleep(3000);
            System.out.println();
            System.out.println();

            System.out.println("Narrator: Every Minecraft save starts with the seed number...");
            Thread.sleep(2000);
            System.out.println();
            System.out.println("*** insert seed number ***");
            Thread.sleep(1000);
            int meansNothing = input.nextInt();
            System.out.println();
            System.out.println("*** Loading World ***");
            Thread.sleep(4000);
            System.out.println();
            System.out.println("Narrator: I'm just kidding there is only one map.");
            Thread.sleep(2000);
            System.out.println();
            System.out.println();


            String nome = jogador.getNome();
            final int maxHP = jogador.getMaxHP();
            final int currentHP = maxHP;
            final int forca = jogador.getForca();
            final int nivel = jogador.getNivel();
            final int ouro = jogador.getOuro();
            final ArmaPrincipal armaPrincipal = jogador.getArmaPrincipal();

            novoJogo.modedMinecraft(jogador);

            if (jogador.getCurrentHP() <= 0) {
                System.out.println("Narrator: That didn't go so well did it?");
                System.out.println();
            }
            if (jogador.getCurrentHP() > 0) {
                System.out.println("Congratulations Steve!");
                System.out.println();
            }

            //depois de morrer opção para novo jogo, continuar com o mesmo heroi ou sair

            do {
                System.out.println("*** Main Menu ***");
                System.out.println();
                System.out.println("1- New Game");
                System.out.println("2- Restart with the same Hero");
                System.out.println("3- Leave");
                opcao = input.nextInt();

                switch (opcao) {

                    case 1:
                        System.out.println("New Game");
                        break;

                    case 2:
                        System.out.println("Lets go again");

                        Heroi clone = null;

                        if (jogador instanceof Cavaleiro) {
                            clone = new Cavaleiro(nome, currentHP, maxHP, forca, nivel, ouro, armaPrincipal);
                        }
                        if (jogador instanceof Feiticeiro) {
                            clone = new Feiticeiro(nome, currentHP, maxHP, forca, nivel, ouro, armaPrincipal);
                        }
                        if (jogador instanceof Arqueiro) {
                            clone = new Arqueiro(nome, currentHP, maxHP, forca, nivel, ouro, armaPrincipal);
                        }

                        // reiniciar mesma personagem
                        novoJogo.modedMinecraft(clone);

                        if (clone.getCurrentHP() <= 0) {
                            System.out.println("Narrator: That didn't go so well did it?");
                            System.out.println();
                        }
                        if (clone.getCurrentHP() > 0) {
                            System.out.println("Congratulations Steve!");
                            System.out.println();
                        }
                        break;

                    case 3:
                        System.out.println("Bye, come again!");
                        break;
                }
            } while (opcao == 2);


        } while (opcao != 3);

    }
}
